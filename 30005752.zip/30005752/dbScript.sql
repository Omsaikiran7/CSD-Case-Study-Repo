CREATE DATABASE CustomerService;
USE CustomerService;

CREATE TABLE Customer (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(15)
);

INSERT INTO Customer (name, email, phone) VALUES
('John Doe', 'john.doe@example.com', '1234567890'),
('Jane Smith', 'jane.smith@example.com', '0987654321'),
('Alice Johnson', 'alice.johnson@example.com', '5551234567');

SELECT * FROM Customer;

-- DROP TABLE Customer;

CREATE TABLE Representative (
    representative_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL
);

INSERT INTO Representative (name) VALUES
('Alice Brown'),
('Bob White'),
('Charlie Green');

SELECT * FROM Representative;

-- DROP TABLE Representative;

CREATE TABLE Ticket (
    ticket_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT,
    creation_date DATE,
    issue_description TEXT,
    status VARCHAR(50),
    FOREIGN KEY (customer_id) REFERENCES Customer(customer_id)
);

INSERT INTO Ticket (customer_id, creation_date, issue_description, status) VALUES
(1, '2023-07-01', 'Issue with the TV not turning on.', 'Open'),
(2, '2023-07-02', 'Laptop battery not charging.', 'Open'),
(3, '2023-07-03', 'Smartphone screen cracked.', 'Open');

SELECT * FROM Ticket;

-- DROP TABLE Ticket;

CREATE TABLE Assignment (
    assignment_id INT AUTO_INCREMENT PRIMARY KEY,
    ticket_id INT,
    representative_id INT,
    assignment_date DATE,
    status VARCHAR(50),
    FOREIGN KEY (ticket_id) REFERENCES Ticket(ticket_id),
    FOREIGN KEY (representative_id) REFERENCES Representative(representative_id)
);


INSERT INTO Assignment (ticket_id, representative_id, assignment_date, status) VALUES
(1, 1, '2023-07-04', 'Assigned'),
(2, 2, '2023-07-05', 'Assigned'),
(3, 3, '2023-07-06', 'Assigned');

SELECT * FROM Assignment;

-- DROP TABLE Assignment;

CREATE TABLE Resolution (
    resolution_id INT AUTO_INCREMENT PRIMARY KEY,
    ticket_id INT,
    resolution_date DATE,
    resolution_details TEXT,
    status VARCHAR(50),
    FOREIGN KEY (ticket_id) REFERENCES Ticket(ticket_id)
);


INSERT INTO Resolution (ticket_id, resolution_date, resolution_details, status) VALUES
(1, '2023-07-10', 'TV power supply replaced.', 'open'),
(2, '2023-07-11', 'Laptop battery replaced.', 'closed'),
(3, '2023-07-12', 'Smartphone screen replaced.', 'open');

SELECT * FROM Resolution;

-- DROP TABLE Resolution;