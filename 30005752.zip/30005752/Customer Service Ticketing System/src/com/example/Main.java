package com.example;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            Connection conn = DatabaseConnectionManager.getConnection();
            System.out.println("Database connection established successfully.");

            // Create manager instances
            TicketManager ticketManager = new TicketManager();
            AssignmentManager assignmentManager = new AssignmentManager();
            ResolutionManager resolutionManager = new ResolutionManager();

            // Menu loop
            while (true) {
                System.out.println("\nCustomer Service Ticketing System");
                System.out.println("1. Create a new ticket");
                System.out.println("2. View all tickets"); // Moved up
                System.out.println("3. View ticket details"); // Previous case 2 moved down
                System.out.println("4. Update ticket information");
                System.out.println("5. Delete a ticket");
                System.out.println("6. Assign a ticket");
                System.out.println("7. View all assigned tickets");
                System.out.println("8. View assigned tickets");
                System.out.println("9. Update assignment information");
                System.out.println("10. Delete assignment records");
                System.out.println("11. Resolve a ticket");
                System.out.println("12. View resolved tickets");
                System.out.println("13. View all resolved tickets");
                System.out.println("14. Update resolution information");
                System.out.println("15. Delete resolution records");
                System.out.println("16. Exit");
                System.out.print("Enter your choice: ");

                // Check if next input is an integer
                if (scanner.hasNextInt()) {
                    int choice = scanner.nextInt();
                    scanner.nextLine(); // Consume newline

                    switch (choice) {
                        case 1:
                            ticketManager.createTicket(scanner);
                            break;
                        case 2:
                            ticketManager.viewAllTickets(); // Moved to the new position
                            break;
                        case 3:
                            ticketManager.viewTicketDetails(scanner); // Moved down
                            break;
                        case 4:
                            ticketManager.updateTicketInformation(scanner);
                            break;
                        case 5:
                            ticketManager.deleteTicket(scanner);
                            break;
                        case 6:
                            assignmentManager.assignTicket(scanner);
                            break;
                        case 7:
                            assignmentManager.viewAllAssignedTickets();
                            break;
                        case 8:
                            assignmentManager.viewAssignedTickets(scanner);
                            break;
                        case 9:
                             assignmentManager.updateAssignmentInformation(scanner);
                            break;
                        case 10:
                             assignmentManager.deleteAssignment(scanner);
                            break;
                        case 11:
                            resolutionManager.resolveTicket(scanner);
                            break;
                        case 12:
                            resolutionManager.viewResolvedTickets(scanner);
                            break;
                        case 13:
                             resolutionManager.viewAllResolvedTickets();
                            break;
                        case 14:
                             resolutionManager.updateResolutionInformation(scanner);
                            break;
                        case 15:
                             resolutionManager.deleteResolution(scanner);
                            break;
                        case 16:
                            System.out.println("Exiting...");
                            DatabaseConnectionManager.closeConnection(); // Close the connection when done
                            return;
                        default:
                            System.out.println("Invalid choice. Please try again.");
                    }
                } else {
                    System.out.println("Invalid input. Please enter a number.");
                    scanner.next(); // Consume the invalid input
                }

                // Wait for user input before returning to menu
                System.out.print("\n\nPress Enter to return to the main menu...");
                scanner.nextLine(); // Wait for the Enter key
            }
        } catch (SQLException e) {
            System.err.println("Failed to establish database connection.");
            e.printStackTrace();
        } finally {
            // Close the scanner if it's no longer needed
            scanner.close();
        }
    }
}


