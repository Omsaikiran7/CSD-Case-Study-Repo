package com.example;

import java.sql.*;
import java.util.Scanner;

public class TicketManager {

    public void createTicket(Scanner scanner) {
        try (Connection conn = DatabaseConnectionManager.getConnection();) {
            System.out.print("Enter customer ID: ");
            int customerId = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            System.out.print("Enter issue description: ");
            String issueDescription = scanner.nextLine();
            String status = "open";

            String sql = "INSERT INTO Ticket (customer_id, creation_date, issue_description, status) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, customerId);
            pstmt.setDate(2, new Date(System.currentTimeMillis()));
            pstmt.setString(3, issueDescription);
            pstmt.setString(4, status);
            pstmt.executeUpdate();

            System.out.println("Ticket created successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewTicketDetails(Scanner scanner) {
        try (Connection conn = DatabaseConnectionManager.getConnection();) {
            System.out.print("Enter ticket ID: ");
            int ticketId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            String sql = "SELECT * FROM Ticket WHERE ticket_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, ticketId);
            ResultSet rs = pstmt.executeQuery();

            // Print header
            System.out.println("+------------+--------------+---------------------+---------------------------+--------+");
            System.out.println("| Ticket ID  | Customer ID | Creation Date       | Issue Description          | Status |");
            System.out.println("+------------+--------------+---------------------+---------------------------+--------+");

            // Print results
            boolean found = false;
            while (rs.next()) {
                System.out.printf("| %-10d | %-12d | %-19s | %-25s | %-6s |\n",
                        rs.getInt("ticket_id"),
                        rs.getInt("customer_id"),
                        rs.getDate("creation_date"),
                        rs.getString("issue_description"),
                        rs.getString("status"));
                found = true;
            }

            if (!found) {
                System.out.println("| No ticket found with the given ID.                                                       |");
            }

            // Print footer
            System.out.println("+------------+--------------+---------------------+---------------------------+--------+");

        } catch (SQLException e) {
            System.err.println("Error connecting to the database: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void viewAllTickets() {
        try (Connection conn = DatabaseConnectionManager.getConnection();) {
            String sql = "SELECT * FROM Ticket";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            // Print header
            System.out.println("+------------+--------------+---------------------+---------------------------+--------+");
            System.out.println("| Ticket ID  | Customer ID | Creation Date       | Issue Description          | Status |");
            System.out.println("+------------+--------------+---------------------+---------------------------+--------+");

            // Print results
            boolean found = false;
            while (rs.next()) {
                System.out.printf("| %-10d | %-12d | %-19s | %-25s | %-6s |\n",
                        rs.getInt("ticket_id"),
                        rs.getInt("customer_id"),
                        rs.getDate("creation_date"),
                        rs.getString("issue_description"),
                        rs.getString("status"));
                found = true;
            }

            if (!found) {
                System.out.println("| No tickets found.                                                                      |");
            }

            // Print footer
            System.out.println("+------------+--------------+---------------------+---------------------------+--------+");

        } catch (SQLException e) {
            System.err.println("Error connecting to the database: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void updateTicketInformation(Scanner scanner) {
        try (Connection conn = DatabaseConnectionManager.getConnection()) {
            System.out.print("Enter ticket ID to update: ");
            int ticketId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            // Fetch current status
            String statusQuery = "SELECT status FROM Ticket WHERE ticket_id = ?";
            PreparedStatement statusStmt = conn.prepareStatement(statusQuery);
            statusStmt.setInt(1, ticketId);
            ResultSet rs = statusStmt.executeQuery();

            if (rs.next()) {
                String currentStatus = rs.getString("status");

                if ("Open".equalsIgnoreCase(currentStatus)) {
                    System.out.print("Enter new issue description: ");
                    String issueDescription = scanner.nextLine();

                    String updateQuery = "UPDATE Ticket SET issue_description = ? WHERE ticket_id = ?";
                    PreparedStatement updateStmt = conn.prepareStatement(updateQuery);
                    updateStmt.setString(1, issueDescription);
                    updateStmt.setInt(2, ticketId);
                    int rowsAffected = updateStmt.executeUpdate();

                    if (rowsAffected > 0) {
                        System.out.println("Ticket updated successfully.");
                    } else {
                        System.out.println("No ticket found with the given ID.");
                    }
                } else {
                    System.out.println("Cannot update the ticket. The status is 'Close'.");
                }
            } else {
                System.out.println("No ticket found with the given ID.");
            }
        } catch (SQLException e) {
            System.err.println("Error connecting to the database: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void deleteTicket(Scanner scanner) {
        try (Connection conn = DatabaseConnectionManager.getConnection();) {
            System.out.print("Enter ticket ID to delete: ");
            int ticketId = scanner.nextInt();

            String sql = "DELETE FROM Ticket WHERE ticket_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, ticketId);
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Ticket deleted successfully.");
            } else {
                System.out.println("No ticket found with the given ID.");
            }
        } catch (SQLException e) {
            System.err.println("Error connecting to the database: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
