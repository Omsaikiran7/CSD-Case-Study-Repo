package com.example;

import java.sql.*;
import java.util.Scanner;

public class ResolutionManager {

    public void resolveTicket(Scanner scanner) {
        try (Connection conn = DatabaseConnectionManager.getConnection()) {
            System.out.print("Enter ticket ID: ");
            int ticketId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            // Check if the ticket is open before resolving it
            String statusQuery = "SELECT status FROM Ticket WHERE ticket_id = ?";
            PreparedStatement statusStmt = conn.prepareStatement(statusQuery);
            statusStmt.setInt(1, ticketId);
            ResultSet rs = statusStmt.executeQuery();

            if (rs.next()) {
                String currentStatus = rs.getString("status");

                if ("Open".equalsIgnoreCase(currentStatus)) {
                    System.out.print("Enter resolution details: ");
                    String resolutionDetails = scanner.nextLine();

                    // Insert resolution details
                    String resolutionSql = "INSERT INTO Resolution (ticket_id, resolution_date, resolution_details, status) VALUES (?, ?, ?, ?)";
                    PreparedStatement resolutionStmt = conn.prepareStatement(resolutionSql);
                    resolutionStmt.setInt(1, ticketId);
                    resolutionStmt.setDate(2, new Date(System.currentTimeMillis()));
                    resolutionStmt.setString(3, resolutionDetails);
                    resolutionStmt.setString(4, "Closed");
                    resolutionStmt.executeUpdate();

                    // Update ticket status to "Closed"
                    String updateTicketStatusSql = "UPDATE Ticket SET status = ? WHERE ticket_id = ?";
                    PreparedStatement updateTicketStatusStmt = conn.prepareStatement(updateTicketStatusSql);
                    updateTicketStatusStmt.setString(1, "Closed");
                    updateTicketStatusStmt.setInt(2, ticketId);
                    updateTicketStatusStmt.executeUpdate();

                    System.out.println("Ticket resolved and status updated to 'Closed' successfully.");
                } else {
                    System.out.println("Cannot resolve the ticket. The status is not 'Open'.");
                }
            } else {
                System.out.println("No ticket found with the given ID.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public void viewResolvedTickets(Scanner scanner) {
        try (Connection conn = DatabaseConnectionManager.getConnection();) {
            System.out.print("Enter ticket ID: ");
            int ticketId = scanner.nextInt();

            String sql = "SELECT * FROM Resolution WHERE ticket_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, ticketId);
            ResultSet rs = pstmt.executeQuery();

            // Print header
            System.out.println("+--------------+-----------+-------------------+-----------------------------------------+--------+");
            System.out.println("| Resolution ID| Ticket ID | Resolution Date   | Resolution Details                      | Status |");
            System.out.println("+--------------+-----------+-------------------+-----------------------------------------+--------+");

            // Print results
            boolean found = false;
            while (rs.next()) {
                System.out.printf("| %-12d | %-9d | %-17s | %-39s | %-6s |\n",
                        rs.getInt("resolution_id"),
                        rs.getInt("ticket_id"),
                        rs.getDate("resolution_date"),
                        rs.getString("resolution_details"),
                        rs.getString("status"));
                found = true;
            }

            if (!found) {
                System.out.println("| No resolutions found for the given ticket ID.                                                |");
            }

            // Print footer
            System.out.println("+--------------+-----------+-------------------+-----------------------------------------+--------+");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewAllResolvedTickets() {
        try (Connection conn = DatabaseConnectionManager.getConnection();) {
            String sql = "SELECT * FROM Resolution";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            // Print header
            System.out.println("+--------------+-----------+-------------------+-----------------------------------------+--------+");
            System.out.println("| Resolution ID| Ticket ID | Resolution Date   | Resolution Details                      | Status |");
            System.out.println("+--------------+-----------+-------------------+-----------------------------------------+--------+");

            // Print results
            boolean found = false;
            while (rs.next()) {
                System.out.printf("| %-12d | %-9d | %-17s | %-39s | %-6s |\n",
                        rs.getInt("resolution_id"),
                        rs.getInt("ticket_id"),
                        rs.getDate("resolution_date"),
                        rs.getString("resolution_details"),
                        rs.getString("status"));
                found = true;
            }

            if (!found) {
                System.out.println("| No resolved tickets found.                                                                  |");
            }

            // Print footer
            System.out.println("+--------------+-----------+-------------------+-----------------------------------------+--------+");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

//    public void updateResolutionInformation(Scanner scanner) {
//        try (Connection conn = DatabaseConnectionManager.getConnection();) {
//            System.out.print("Enter resolution ID to update: ");
//            int resolutionId = scanner.nextInt();
//            scanner.nextLine(); // Consume newline
//
//            System.out.print("Enter new resolution details: ");
//            String resolutionDetails = scanner.nextLine();
//            System.out.print("Enter new resolution status: ");
//            String status = scanner.nextLine();
//
//            String sql = "UPDATE Resolution SET resolution_details = ?, status = ? WHERE resolution_id = ?";
//            PreparedStatement pstmt = conn.prepareStatement(sql);
//            pstmt.setString(1, resolutionDetails);
//            pstmt.setString(2, status);
//            pstmt.setInt(3, resolutionId);
//            int rowsAffected = pstmt.executeUpdate();
//
//            if (rowsAffected > 0) {
//                System.out.println("Resolution updated successfully.");
//            } else {
//                System.out.println("No resolution found with the given ID.");
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }

    public void updateResolutionInformation(Scanner scanner) {
        try (Connection conn = DatabaseConnectionManager.getConnection()) {
            System.out.print("Enter resolution ID to update: ");
            int resolutionId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            // Fetch current status and ticket ID
            String statusQuery = "SELECT status, ticket_id FROM Resolution WHERE resolution_id = ?";
            PreparedStatement statusStmt = conn.prepareStatement(statusQuery);
            statusStmt.setInt(1, resolutionId);
            ResultSet rs = statusStmt.executeQuery();

            if (rs.next()) {
                String currentStatus = rs.getString("status");
                int ticketId = rs.getInt("ticket_id");

                if ("Open".equalsIgnoreCase(currentStatus)) {
                    System.out.print("Enter new resolution details: ");
                    String resolutionDetails = scanner.nextLine();

                    System.out.print("Enter new resolution status: ");
                    String status = scanner.nextLine();

                    // Start transaction
                    conn.setAutoCommit(false);

                    try {
                        String updateResolutionSql = "UPDATE Resolution SET resolution_details = ?, status = ? WHERE resolution_id = ?";
                        PreparedStatement updateResolutionStmt = conn.prepareStatement(updateResolutionSql);
                        updateResolutionStmt.setString(1, resolutionDetails);
                        updateResolutionStmt.setString(2, status);
                        updateResolutionStmt.setInt(3, resolutionId);
                        int rowsAffected = updateResolutionStmt.executeUpdate();

                        if (rowsAffected > 0) {
                            System.out.println("Resolution updated successfully.");

                            if ("Closed".equalsIgnoreCase(status)) {
                                String updateTicketStatusSql = "UPDATE Ticket SET status = ? WHERE ticket_id = ?";
                                PreparedStatement updateTicketStatusStmt = conn.prepareStatement(updateTicketStatusSql);
                                updateTicketStatusStmt.setString(1, "Closed");
                                updateTicketStatusStmt.setInt(2, ticketId);
                                updateTicketStatusStmt.executeUpdate();
                            }

                            conn.commit();
                        } else {
                            System.out.println("No resolution found with the given ID.");
                            conn.rollback();
                        }
                    } catch (SQLException e) {
                        conn.rollback();
                        throw e;
                    } finally {
                        conn.setAutoCommit(true);
                    }
                } else {
                    System.out.println("Cannot update the resolution. The status is 'Closed'.");
                }
            } else {
                System.out.println("No resolution found with the given ID.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public void deleteResolution(Scanner scanner) {
        try (Connection conn = DatabaseConnectionManager.getConnection();) {
            System.out.print("Enter resolution ID to delete: ");
            int resolutionId = scanner.nextInt();

            String sql = "DELETE FROM Resolution WHERE resolution_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, resolutionId);
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Resolution deleted successfully.");
            } else {
                System.out.println("No resolution found with the given ID.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
