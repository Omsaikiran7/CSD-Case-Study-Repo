package com.example;

import java.sql.*;
import java.util.Scanner;

public class AssignmentManager {

    public void assignTicket(Scanner scanner) {
        try (Connection conn = DatabaseConnectionManager.getConnection()) {
            System.out.print("Enter ticket ID: ");
            int ticketId = scanner.nextInt();
            System.out.print("Enter representative ID: ");
            int representativeId = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            String status = "Assigned";

            boolean exitIf = false;
            if (!ticketExists(conn, ticketId)) {
                System.out.println("Ticket ID " + ticketId + " does not exist.");
                exitIf = true;
            }

            if (!representativeExists(conn, representativeId)) {
                System.out.println("Representative ID " + representativeId + " does not exist.");
                exitIf = true;
            }

            if (isTicketAlreadyAssigned(conn, ticketId)) {
                System.out.println("Ticket ID " + ticketId + " is already assigned.");
                exitIf = true;
            }

            if(exitIf){
                return;
            }

            String sql = "INSERT INTO Assignment (ticket_id, representative_id, assignment_date, status) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, ticketId);
            pstmt.setInt(2, representativeId);
            pstmt.setDate(3, new Date(System.currentTimeMillis()));
            pstmt.setString(4, status);
            pstmt.executeUpdate();

            System.out.println("Ticket assigned successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private boolean isTicketAlreadyAssigned(Connection conn, int ticketId) throws SQLException {
        String sql = "SELECT 1 FROM Assignment WHERE ticket_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, ticketId);
            ResultSet rs = pstmt.executeQuery();
            return rs.next();
        }
    }

    private boolean ticketExists(Connection conn, int ticketId) throws SQLException {
        String sql = "SELECT 1 FROM Ticket WHERE ticket_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, ticketId);
            ResultSet rs = pstmt.executeQuery();
            return rs.next();
        }
    }

    private boolean representativeExists(Connection conn, int representativeId) throws SQLException {
        String sql = "SELECT 1 FROM Representative WHERE representative_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, representativeId);
            ResultSet rs = pstmt.executeQuery();
            return rs.next();
        }
    }

    public void viewAssignedTickets(Scanner scanner) {
        try (Connection conn = DatabaseConnectionManager.getConnection()) {
            System.out.print("Enter representative ID: ");
            int representativeId = scanner.nextInt();

            String sql = "SELECT * FROM Assignment WHERE representative_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, representativeId);
            ResultSet rs = pstmt.executeQuery();

            // Print header
            System.out.println("+---------------+-----------+-------------------+---------------------+------------+");
            System.out.println("| Assignment ID | Ticket ID | Representative ID | Assignment Date     | Status     |");
            System.out.println("+---------------+-----------+-------------------+---------------------+------------+");

            // Print results
            boolean found = false;
            while (rs.next()) {
                System.out.printf("| %-13d | %-9d | %-19s | %-6s |\n",
                        rs.getInt("assignment_id"),
                        rs.getInt("ticket_id"),
                        rs.getDate("assignment_date"),
                        rs.getString("status"));
                found = true;
            }

            if (!found) {
                System.out.println("| No assignments found for the given representative ID.         |");
            }

            // Print footer
            System.out.println("+---------------+-----------+-------------------+---------------------+------------+");

            scanner.nextLine(); // Consume newline
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewAllAssignedTickets() {
        try (Connection conn = DatabaseConnectionManager.getConnection()) {
            String sql = "SELECT * FROM Assignment";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            // Print header
            System.out.println("+---------------+-----------+-------------------+---------------------+------------+");
            System.out.println("| Assignment ID | Ticket ID | Representative ID | Assignment Date     | Status     |");
            System.out.println("+---------------+-----------+-------------------+---------------------+------------+");

            // Print results
            boolean found = false;
            while (rs.next()) {
                System.out.printf("| %-13d | %-9d | %-17d | %-19s | %-10s |\n",
                        rs.getInt("assignment_id"),
                        rs.getInt("ticket_id"),
                        rs.getInt("representative_id"),
                        rs.getDate("assignment_date"),
                        rs.getString("status"));
                found = true;
            }

            if (!found) {
                System.out.println("| No assignments found.                                       |");
            }

            // Print footer
            System.out.println("+---------------+-----------+-------------------+---------------------+------------+");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Other methods (updateAssignmentInformation, deleteAssignment) will be similar, using `DatabaseConnectionManager`
    public void deleteAssignment(Scanner scanner) {
        try (Connection conn = DatabaseConnectionManager.getConnection()) {
            System.out.print("Enter assignment ID to delete: ");
            int assignmentId = scanner.nextInt();

            String sql = "DELETE FROM Assignment WHERE assignment_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, assignmentId);
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Assignment deleted successfully.");
            } else {
                System.out.println("No assignment found with the given ID.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateAssignmentInformation(Scanner scanner) {
        try (Connection conn = DatabaseConnectionManager.getConnection()) {
            System.out.print("Enter assignment ID to update: ");
            int assignmentId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            System.out.print("Enter new status: ");
            String status = scanner.nextLine();

            String sql = "UPDATE Assignment SET status = ? WHERE assignment_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, status);
            pstmt.setInt(2, assignmentId);
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Assignment updated successfully.");
            } else {
                System.out.println("No assignment found with the given ID.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
