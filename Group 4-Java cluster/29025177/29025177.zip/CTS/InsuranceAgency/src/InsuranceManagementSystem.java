import java.sql.*;
import java.util.Scanner;

public class InsuranceManagementSystem {
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("Insurance Management System");
            System.out.println("1. Policy Management");
            System.out.println("2. Client Management");
            System.out.println("3. Claim Management");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    managePolicies();
                    break;
                case 2:
                    manageClients();
                    break;
                case 3:
                    manageClaims();
                    break;
                case 4:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    private static void managePolicies() {
        while (true) {
            System.out.println("Policy Management");
            System.out.println("1. Add Policy");
            System.out.println("2. View Policy");
            System.out.println("3. Update Policy");
            System.out.println("4. Delete Policy");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addPolicy();
                    break;
                case 2:
                    viewPolicy();
                    break;
                case 3:
                    updatePolicy();
                    break;
                case 4:
                    deletePolicy();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    private static void manageClients() {
        while (true) {
            System.out.println("Client Management");
            System.out.println("1. Register Client");
            System.out.println("2. View Client");
            System.out.println("3. Update Client");
            System.out.println("4. Delete Client");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    registerClient();
                    break;
                case 2:
                    viewClient();
                    break;
                case 3:
                    updateClient();
                    break;
                case 4:
                    deleteClient();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    private static void manageClaims() {
        while (true) {
            System.out.println("Claim Management");
            System.out.println("1. Submit Claim");
            System.out.println("2. View Claim");
            System.out.println("3. Update Claim");
            System.out.println("4. Delete Claim");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    submitClaim();
                    break;
                case 2:
                    viewClaim();
                    break;
                case 3:
                    updateClaim();
                    break;
                case 4:
                    deleteClaim();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    // Policy Management Methods
    private static void addPolicy() {
        System.out.print("Enter Policy Number: ");
        String policyNumber = scanner.nextLine();
        System.out.print("Enter Policy Type: ");
        String type = scanner.nextLine();
        System.out.print("Enter Coverage Amount: ");
        double coverageAmount = scanner.nextDouble();
        System.out.print("Enter Premium Amount: ");
        double premiumAmount = scanner.nextDouble();
        scanner.nextLine(); // Consume newline

        String query = "INSERT INTO Policy (policy_number, type, coverage_amount, premium_amount) VALUES (?, ?, ?, ?)";

        try (Connection connection = JDBCUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, policyNumber);
            preparedStatement.setString(2, type);
            preparedStatement.setDouble(3, coverageAmount);
            preparedStatement.setDouble(4, premiumAmount);
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Policy added successfully!");
            } else {
                System.out.println("Failed to add policy.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewPolicy() {
        System.out.print("Enter Policy ID to View: ");
        int policyId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        String query = "SELECT * FROM Policy WHERE policy_id = ?";

        try (Connection connection = JDBCUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, policyId);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                System.out.println("Policy ID: " + resultSet.getInt("policy_id"));
                System.out.println("Policy Number: " + resultSet.getString("policy_number"));
                System.out.println("Type: " + resultSet.getString("type"));
                System.out.println("Coverage Amount: " + resultSet.getDouble("coverage_amount"));
                System.out.println("Premium Amount: " + resultSet.getDouble("premium_amount"));
            } else {
                System.out.println("Policy not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updatePolicy() {
        System.out.print("Enter Policy ID to Update: ");
        int policyId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.print("Enter New Policy Number: ");
        String policyNumber = scanner.nextLine();
        System.out.print("Enter New Policy Type: ");
        String type = scanner.nextLine();
        System.out.print("Enter New Coverage Amount: ");
        double coverageAmount = scanner.nextDouble();
        System.out.print("Enter New Premium Amount: ");
        double premiumAmount = scanner.nextDouble();
        scanner.nextLine(); // Consume newline

        String query = "UPDATE Policy SET policy_number = ?, type = ?, coverage_amount = ?, premium_amount = ? WHERE policy_id = ?";

        try (Connection connection = JDBCUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, policyNumber);
            preparedStatement.setString(2, type);
            preparedStatement.setDouble(3, coverageAmount);
            preparedStatement.setDouble(4, premiumAmount);
            preparedStatement.setInt(5, policyId);
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Policy updated successfully!");
            } else {
                System.out.println("Failed to update policy.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deletePolicy() {
        System.out.print("Enter Policy ID to Delete: ");
        int policyId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        String query = "DELETE FROM Policy WHERE policy_id = ?";

        try (Connection connection = JDBCUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, policyId);
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Policy deleted successfully!");
            } else {
                System.out.println("Failed to delete policy.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Client Management Methods
    private static void registerClient() {
        System.out.print("Enter Client Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Client Email: ");
        String email = scanner.nextLine();
        System.out.print("Enter Client Phone Number: ");
        String phoneNumber = scanner.nextLine();
        System.out.print("Enter Client Address: ");
        String address = scanner.nextLine();

        String query = "INSERT INTO Client (name, email, phone_number, address) VALUES (?, ?, ?, ?)";

        try (Connection connection = JDBCUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, email);
            preparedStatement.setString(3, phoneNumber);
            preparedStatement.setString(4, address);
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Client registered successfully!");
            } else {
                System.out.println("Failed to register client.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewClient() {
        System.out.print("Enter Client ID to View: ");
        int clientId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        String query = "SELECT * FROM Client WHERE client_id = ?";

        try (Connection connection = JDBCUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, clientId);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                System.out.println("Client ID: " + resultSet.getInt("client_id"));
                System.out.println("Name: " + resultSet.getString("name"));
                System.out.println("Email: " + resultSet.getString("email"));
                System.out.println("Phone Number: " + resultSet.getString("phone_number"));
                System.out.println("Address: " + resultSet.getString("address"));
            } else {
                System.out.println("Client not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateClient() {
        System.out.print("Enter Client ID to Update: ");
        int clientId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.print("Enter New Client Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter New Client Email: ");
        String email = scanner.nextLine();
        System.out.print("Enter New Client Phone Number: ");
        String phoneNumber = scanner.nextLine();
        System.out.print("Enter New Client Address: ");
        String address = scanner.nextLine();

        String query = "UPDATE Client SET name = ?, email = ?, phone_number = ?, address = ? WHERE client_id = ?";

        try (Connection connection = JDBCUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, email);
            preparedStatement.setString(3, phoneNumber);
            preparedStatement.setString(4, address);
            preparedStatement.setInt(5, clientId);
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Client updated successfully!");
            } else {
                System.out.println("Failed to update client.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteClient() {
        System.out.print("Enter Client ID to Delete: ");
        int clientId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        String query = "DELETE FROM Client WHERE client_id = ?";

        try (Connection connection = JDBCUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, clientId);
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Client deleted successfully!");
            } else {
                System.out.println("Failed to delete client.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Claim Management Methods
    private static void submitClaim() {
        System.out.print("Enter Policy ID: ");
        int policyId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter Client ID: ");
        int clientId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter Claim Date (YYYY-MM-DD): ");
        String claimDate = scanner.nextLine();
        System.out.print("Enter Claim Status: ");
        String status = scanner.nextLine();

        String query = "INSERT INTO Claim (policy_id, client_id, claim_date, status) VALUES (?, ?, ?, ?)";

        try (Connection connection = JDBCUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, policyId);
            preparedStatement.setInt(2, clientId);
            preparedStatement.setDate(3, Date.valueOf(claimDate));
            preparedStatement.setString(4, status);
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Claim submitted successfully!");
            } else {
                System.out.println("Failed to submit claim.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewClaim() {
        System.out.print("Enter Claim ID to View: ");
        int claimId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        String query = "SELECT * FROM Claim WHERE claim_id = ?";

        try (Connection connection = JDBCUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, claimId);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                System.out.println("Claim ID: " + resultSet.getInt("claim_id"));
                System.out.println("Policy ID: " + resultSet.getInt("policy_id"));
                System.out.println("Client ID: " + resultSet.getInt("client_id"));
                System.out.println("Claim Date: " + resultSet.getDate("claim_date"));
                System.out.println("Status: " + resultSet.getString("status"));
            } else {
                System.out.println("Claim not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateClaim() {
        System.out.print("Enter Claim ID to Update: ");
        int claimId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.print("Enter New Policy ID: ");
        int policyId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter New Client ID: ");
        int clientId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter New Claim Date (YYYY-MM-DD): ");
        String claimDate = scanner.nextLine();
        System.out.print("Enter New Claim Status: ");
        String status = scanner.nextLine();

        String query = "UPDATE Claim SET policy_id = ?, client_id = ?, claim_date = ?, status = ? WHERE claim_id = ?";

        try (Connection connection = JDBCUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, policyId);
            preparedStatement.setInt(2, clientId);
            preparedStatement.setDate(3, Date.valueOf(claimDate));
            preparedStatement.setString(4, status);
            preparedStatement.setInt(5, claimId);
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Claim updated successfully!");
            } else {
                System.out.println("Failed to update claim.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteClaim() {
        System.out.print("Enter Claim ID to Delete: ");
        int claimId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        String query = "DELETE FROM Claim WHERE claim_id = ?";

        try (Connection connection = JDBCUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, claimId);
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Claim deleted successfully!");
            } else {
                System.out.println("Failed to delete claim.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

