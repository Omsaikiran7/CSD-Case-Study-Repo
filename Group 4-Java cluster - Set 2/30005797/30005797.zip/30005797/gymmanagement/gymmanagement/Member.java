package gymmanagement;

public class Member {
    private int id;
    private String name;
    private String Description;
    private String email;

    // Constructor for creating a new member
    public Member(String name, String email) {
        this.name = name;
        this.email = email;
    }

    // Constructor for creating a member with an ID (e.g., from the database)
    public Member(int id, String name, String email) {
        this.id = id;
        this.name = name;
        this.email = email;


    }

    // Getter for ID
    public int getId() {
        return id;
    }

    // Setter for ID
    public void setId(int id) {
        this.id = id;
    }

    // Getter for Name
    public String getName() {
        return name;
    }

    // Setter for Name
    public void setName(String name) {
        this.name = name;
    }

    // Getter for Email
    public String getEmail() {
        return email;
    }

    // Setter for Email
    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "Member{id=" + id + ", name='" + name + "', email='" + email + "'}";
    }
}
