package gymmanagement;

public class MembershipPlan {
    private int Id;
    private String name;
    private String Description;
    private double pricePerMonth;

    // Constructor
    public MembershipPlan(int Id, String name, String Description, double pricePerMonth) {
        this.Id = Id;
        this.name = name;
        this.Description = Description;
        this.pricePerMonth = pricePerMonth;
    }

    // Getters and Setters
    public int getId() {
        return Id;
    }

    public void setId(int planId) {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String Description) {
        this.Description = Description;
    }

    public double getPricePerMonth() {
        return pricePerMonth;
    }

    public void setPricePerMonth(double pricePerMonth) {
        this.pricePerMonth = pricePerMonth;
    }
}
