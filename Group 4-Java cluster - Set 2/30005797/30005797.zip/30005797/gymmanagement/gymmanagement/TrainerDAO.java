package gymmanagement;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TrainerDAO {

    // Method to add a new trainer to the database
    public void addTrainer(Trainer trainer) throws SQLException {
        String query = "INSERT INTO trainers (name, specialty, email) VALUES (?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, trainer.getName());
           // stmt.setString(2, trainer.getSpecialty());
            stmt.setString(3, trainer.getEmail());
            stmt.executeUpdate();
        }
    }

    // Method to get a trainer by ID
    public Trainer getTrainer(int id) throws SQLException {
        String query = "SELECT * FROM trainers WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Trainer(
                            rs.getInt("id"),
                            rs.getString("name"),
                            rs.getString("specialty"),
                            rs.getString("email")
                    );
                } else {
                    return null;
                }
            }
        }
    }

    // Method to update a trainer's information
    public void updateTrainer(Trainer trainer) throws SQLException {
        String query = "UPDATE trainers SET name = ?, specialty = ?, email = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, trainer.getName());
          //  stmt.setString(2, trainer.getSpecialty());
            stmt.setString(3, trainer.getEmail());
            stmt.executeUpdate();
        }
    }

    // Method to delete a trainer by ID
    public void deleteTrainer(int id) throws SQLException {
        String query = "DELETE FROM trainers WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }

    // Method to get all trainers
    public List<Trainer> getAllTrainers() throws SQLException {
        List<Trainer> trainers = new ArrayList<>();
        String query = "SELECT * FROM trainers";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                trainers.add(new Trainer(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("specialty"),
                        rs.getString("email")
                ));
            }
        }
        return trainers;
    }
}
