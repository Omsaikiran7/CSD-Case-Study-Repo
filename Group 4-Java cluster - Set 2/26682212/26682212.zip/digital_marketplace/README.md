# Digital Marketplace

## Overview

Digital Marketplace is a menu-based console application built using Core Java, MySQL, and JDBC. This application simulates a digital marketplace, allowing users to manage products, sellers, and transactions efficiently.

## Features

1. **Product Management:**
   - Add new products to the marketplace.
   - View product details.
   - Update product information.
   - Delete products from the marketplace.

2. **Seller Management:**
   - Register new sellers.
   - View seller details.
   - Update seller information.
   - Delete sellers from the marketplace.

3. **Transaction Management:**
   - Process new transactions.
   - View transaction details.
   - Update transaction status.
   - Refund transactions.

## Database Schema

- **Product Table:**
  - `product_id` (Primary Key)
  - `name`
  - `description`
  - `price`
  - `quantity_available`
  - `category`

- **Seller Table:**
  - `seller_id` (Primary Key)
  - `name`
  - `email`
  - `address`
  - `phone_number`

- **Transaction Table:**
  - `transaction_id` (Primary Key)
  - `product_id` (Foreign Key references Product Table)
  - `seller_id` (Foreign Key references Seller Table)
  - `buyer_id` (Foreign Key references Buyer Table)
  - `quantity`
  - `transaction_date`
  - `status`

## Prerequisites

- Java Development Kit (JDK)
- MySQL Server
- MySQL Connector/J (JDBC Driver)

## Setup Instructions

### 1. Clone the Repository

```sh
git clone https://github.com/your-username/digital-marketplace.git
cd digital-marketplace



2. Set Up the Database
Install MySQL and create the database:

Compile and Run the Application
Use the provided shell script to compile and run the application:

./run.sh

Alternatively, you can compile and run the application manually:

# Compile Java files
javac -cp lib/mysql-connector-java-<version>.jar -d bin src/com/marketplace/**/*.java

# Run the application
java -cp bin:lib/mysql-connector-java-<version>.jar com.marketplace.MarketplaceApp

