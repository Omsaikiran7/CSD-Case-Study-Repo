package com.marketplace.dao;

public class SellerDAO {
    
}
