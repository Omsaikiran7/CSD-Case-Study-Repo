package com.marketplace;

import java.util.Scanner;

public class MarketplaceApp {
    private static final Scanner scanner = new Scanner(System.in);
    private static final ProductDAO productDAO = new ProductDAO();
    private static final SellerDAO sellerDAO = new SellerDAO();
    private static final TransactionDAO transactionDAO = new TransactionDAO();

    public static void main(String[] args) {
        while (true) {
            printMainMenu();
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    manageProducts();
                    break;
                case 2:
                    manageSellers();
                    break;
                case 3:
                    manageTransactions();
                    break;
                case 4:
                    System.out.println("Exiting the application...");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void printMainMenu() {
        System.out.println("Welcome to the Digital Marketplace");
        System.out.println("1. Product Management");
        System.out.println("2. Seller Management");
        System.out.println("3. Transaction Management");
        System.out.println("4. Exit");
        System.out.print("Enter your choice: ");
    }

    private static void manageProducts() {
        // Implement product management menu and operations
    }

    private static void manageSellers() {
        // Implement seller management menu and operations
    }

    private static void manageTransactions() {
        // Implement transaction management menu and operations
    }
}
