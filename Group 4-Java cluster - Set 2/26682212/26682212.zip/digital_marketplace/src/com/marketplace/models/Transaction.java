package com.marketplace.models;

public class Transaction {
    
}
