package com.marketplace.models;

public class Seller {
    
}
