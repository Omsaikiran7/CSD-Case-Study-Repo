
# Digital Magazine Management System

## Description

The Digital Magazine Management System is a console-based application developed using Core Java, MySQL, and JDBC. This application allows users to manage magazines, articles, and subscriptions efficiently. The functionalities include adding, viewing, updating, and deleting magazines and articles, as well as subscribing, viewing, updating, and canceling subscriptions.

## Setup Instructions

### Prerequisites

- Java Development Kit (JDK) 8 or higher
- MySQL Server
- A MySQL client or MySQL Workbench
- An IDE for Java development (e.g., IntelliJ IDEA, Eclipse, NetBeans)

### Steps

1. **Clone the Repository**

   ```sh
   git clone https://github.com/yourusername/digital-magazine-management-system.git
   cd digital-magazine-management-system
   ```

2. **Set Up the MySQL Database**

   Open your MySQL client and run the following SQL scripts to set up the database and tables:

   ```sql
   CREATE DATABASE DigitalMagazineDB;

   USE DigitalMagazineDB;

   CREATE TABLE User (
       user_id INT PRIMARY KEY AUTO_INCREMENT,
       username VARCHAR(50),
       email VARCHAR(100),
       date_of_birth DATE,
       registration_date DATE
   );

   CREATE TABLE Magazine (
       magazine_id INT PRIMARY KEY AUTO_INCREMENT,
       title VARCHAR(100),
       genre VARCHAR(50),
       publication_frequency VARCHAR(50),
       publisher VARCHAR(100)
   );

   CREATE TABLE Article (
       article_id INT PRIMARY KEY AUTO_INCREMENT,
       magazine_id INT,
       title VARCHAR(100),
       author VARCHAR(50),
       content TEXT,
       publish_date DATE,
       FOREIGN KEY (magazine_id) REFERENCES Magazine(magazine_id)
   );

   CREATE TABLE Subscription (
       subscription_id INT PRIMARY KEY AUTO_INCREMENT,
       user_id INT,
       magazine_id INT,
       subscription_date DATE,
       expiry_date DATE,
       status VARCHAR(10),
       FOREIGN KEY (user_id) REFERENCES User(user_id),
       FOREIGN KEY (magazine_id) REFERENCES Magazine(magazine_id)
   );
   ```

3. **Configure Database Connection**

   Open the `DatabaseConnection.java` file and update the database URL, username, and password:

   ```java
   private static final String URL = "jdbc:mysql://localhost:3306/DigitalMagazineDB";
   private static final String USER = "root";
   private static final String PASSWORD = "yourpassword";
   ```

4. **Build and Run the Application**

   Import the project into your favorite IDE. Build the project and run the `Main.java` file.

## Usage Instructions

1. **Run the Application**

   After starting the application, you will see a menu with options to manage magazines, articles, and subscriptions, or to exit the application.

2. **Manage Magazines**

   - **Add Magazine**: Follow the prompts to add a new magazine.
   - **View Magazine**: Enter the magazine ID to view its details.
   - **Update Magazine**: Enter the magazine ID to update its information.
   - **Delete Magazine**: Enter the magazine ID to delete it.

3. **Manage Articles**

   - **Add Article**: Follow the prompts to add a new article to a magazine.
   - **View Article**: Enter the article ID to view its details.
   - **Update Article**: Enter the article ID to update its information.
   - **Delete Article**: Enter the article ID to delete it.

4. **Manage Subscriptions**

   - **Subscribe**: Follow the prompts to subscribe to a magazine.
   - **View Subscription**: Enter the subscription ID to view its details.
   - **Update Subscription**: Enter the subscription ID to update its information.
   - **Cancel Subscription**: Enter the subscription ID to cancel it.

5. **Exit**

   Choose the option to exit the application.

## License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.

## Contributing

If you wish to contribute to this project, please fork the repository and submit a pull request. We appreciate your contributions!

## Contact

For any questions or feedback, please contact (mailto:ritwickghosh37@gmail.com).

```

