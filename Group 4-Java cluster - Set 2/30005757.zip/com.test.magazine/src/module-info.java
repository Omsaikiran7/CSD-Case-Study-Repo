/**
 * 
 */
/**
 * 
 */
module com.test.magazine {
	requires java.sql;
}