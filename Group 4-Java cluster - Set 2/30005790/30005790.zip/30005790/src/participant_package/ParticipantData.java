package participant_package;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ParticipantData {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/event_management";
    private static final String USER = "captain";
    private static final String PASS = "captain@1234";

    public void addParticipant(Participant participant) throws SQLException {
        String sql = "INSERT INTO participant (name, email, phone_number) VALUES (?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, participant.getName());
            stmt.setString(2, participant.getEmail());
            stmt.setString(3, participant.getPhoneNumber());
            stmt.executeUpdate();
        }
    }

    public Participant getParticipant(int id) throws SQLException {
        String sql = "SELECT * FROM participant WHERE participant_id = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Participant(
                            rs.getInt("participant_id"),
                            rs.getString("name"),
                            rs.getString("email"),
                            rs.getString("phone_number")
                    );
                }
            }
        }
        return null;
    }

    public void updateParticipant(Participant participant) throws SQLException {
        String sql = "UPDATE participant SET name = ?, email = ?, phone_number = ? WHERE participant_id = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, participant.getName());
            stmt.setString(2, participant.getEmail());
            stmt.setString(3, participant.getPhoneNumber());
            stmt.setInt(4, participant.getParticipantId());
            stmt.executeUpdate();
        }
    }

    public void deleteParticipant(int id) throws SQLException {
        String sql = "DELETE FROM participant WHERE participant_id = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }

    public List<Participant> getAllParticipants() throws SQLException {
        List<Participant> participants = new ArrayList<>();
        String sql = "SELECT * FROM participant";  
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("participant_id");
                String name = rs.getString("name");
                String email = rs.getString("email");
                String phoneNumber = rs.getString("phone_number");

                Participant participant = new Participant(id, name, email, phoneNumber);
                participants.add(participant);
            }
        }

        return participants;
    }
}
