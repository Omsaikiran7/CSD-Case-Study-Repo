package Default_package;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import event_package.Event;
import event_package.EventData;
import participant_package.Participant;
import participant_package.ParticipantData;
import registration_package.Registration;
import registration_package.RegistrationData;

public class Main {
    private static final EventData eventDAO = new EventData();
    private static final ParticipantData participantDAO = new ParticipantData();
    private static final RegistrationData registrationDAO = new RegistrationData();
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("Menu:");
            System.out.println("===============================");
            System.out.println("1. Event Management");
            System.out.println("2. Participant Management");
            System.out.println("3. Registration Management");
            System.out.println("4. Exit");
            System.out.println("Choose an option: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    manageEvents();
                    break;
                case 2:
                    manageParticipants();
                    break;
                case 3:
                    manageRegistrations();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    System.exit(0);
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void manageEvents() {
        while (true) {
            System.out.println("===============================");
            System.out.println("Event Management:");
            System.out.println("1. Add Event");
            System.out.println("2. View All Events");
            System.out.println("3. Update Event");
            System.out.println("4. Delete Event");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine();
            

            try {
                switch (choice) {
                    case 1:
                        addEvent();
                        break;
                    case 2:
                        viewAllEvents();
                        break;
                    case 3:
                        updateEvent();
                        break;
                    case 4:
                        deleteEvent();
                        break;
                    case 5:
                        return;
                    default:
                        System.out.println("Invalid option. Please try again.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private static void manageParticipants() {
        while (true) {
            System.out.println("Participant Management:");
            System.out.println("1. Add Participant");
            System.out.println("2. View All Participants");
            System.out.println("3. Update Participant");
            System.out.println("4. Delete Participant");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  

            try {
                switch (choice) {
                    case 1:
                        addParticipant();
                        break;
                    case 2:
                        viewAllParticipants();
                        break;
                    case 3:
                        updateParticipant();
                        break;
                    case 4:
                        deleteParticipant();
                        break;
                    case 5:
                        return;
                    default:
                        System.out.println("Invalid option. Please try again.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private static void manageRegistrations() {
        while (true) {
            System.out.println("Registration Management:");
            System.out.println("1. Register Participant for Event");
            System.out.println("2. View Registration Details");
            System.out.println("3. Update Registration");
            System.out.println("4. Cancel Registration");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  

            try {
                switch (choice) {
                    case 1:
                        registerParticipantForEvent();
                        break;
                    case 2:
                        viewAllRegistrationDetails();
                        break;
                    case 3:
                        updateRegistration();
                        break;
                    case 4:
                        cancelRegistration();
                        break;
                    case 5:
                        return;
                    default:
                        System.out.println("Invalid option. Please try again.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private static void addEvent() throws SQLException {
    	System.out.println("===============================");
        System.out.print("Enter event name: ");
        String name = scanner.nextLine();
        System.out.print("Enter event date (YYYY-MM-DD): ");
        String date = scanner.nextLine();
        System.out.print("Enter event location: ");
        String location = scanner.nextLine();
        System.out.print("Enter event description: ");
        String description = scanner.nextLine();
        System.out.print("Enter event capacity: ");
        int capacity = scanner.nextInt();
        scanner.nextLine();

        Event event = new Event(0, name, date, location, description, capacity);
        eventDAO.addEvent(event);
        System.out.println("Event added successfully.");
    }

    private static void viewAllEvents() throws SQLException {
        List<Event> events = eventDAO.getAllEvents();
        if (events.isEmpty()) {
            System.out.println("No events found.");
        } else {
            for (Event event : events) {
            	System.out.println("===============================");
                System.out.println("Event ID: " + event.getEventId());
                System.out.println("Name: " + event.getName());
                System.out.println("Date: " + event.getDate());
                System.out.println("Location: " + event.getLocation());
                System.out.println("Description: " + event.getDescription());
                System.out.println("Capacity: " + event.getCapacity());
                System.out.println();
            }
        }
    }

    private static void updateEvent() throws SQLException {
    	System.out.println("===============================");
        System.out.print("Enter event ID to update: ");
        int eventId = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Enter new event name: ");
        String name = scanner.nextLine();
        System.out.print("Enter new event date (YYYY-MM-DD): ");
        String date = scanner.nextLine();
        System.out.print("Enter new event location: ");
        String location = scanner.nextLine();
        System.out.print("Enter new event description: ");
        String description = scanner.nextLine();
        System.out.print("Enter new event capacity: ");
        int capacity = scanner.nextInt();
        scanner.nextLine(); 

        Event event = new Event(eventId, name, date, location, description, capacity);
        eventDAO.updateEvent(event);
        System.out.println("Event updated successfully.");
    }

    private static void deleteEvent() throws SQLException {
    	System.out.println("===============================");
        System.out.print("Enter event ID to delete: ");
        int eventId = scanner.nextInt();
        scanner.nextLine();

        eventDAO.deleteEvent(eventId);
        System.out.println("Event deleted successfully.");
    }

    private static void addParticipant() throws SQLException {
    	System.out.println("===============================");
        System.out.print("Enter participant name: ");
        String name = scanner.nextLine();
        System.out.print("Enter participant email: ");
        String email = scanner.nextLine();
        System.out.print("Enter participant phone number: ");
        String phoneNumber = scanner.nextLine();

        Participant participant = new Participant(0, name, email, phoneNumber);
        participantDAO.addParticipant(participant);
        System.out.println("Participant added successfully.");
    }

    private static void viewAllParticipants() throws SQLException {
        List<Participant> participants = participantDAO.getAllParticipants();
        if (participants.isEmpty()) {
            System.out.println("No participants found.");
        } else {
            for (Participant participant : participants) {
                System.out.println("=============================");
                System.out.println("Participant ID: " + participant.getParticipantId());
                System.out.println("Name: " + participant.getName());
                System.out.println("Email: " + participant.getEmail());
                System.out.println("Phone Number: " + participant.getPhoneNumber());
                System.out.println();
            }
        }
    }

    private static void updateParticipant() throws SQLException {
    	System.out.println("===============================");
        System.out.print("Enter participant ID to update: ");
        int participantId = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Enter new participant name: ");
        String name = scanner.nextLine();
        System.out.print("Enter new participant email: ");
        String email = scanner.nextLine();
        System.out.print("Enter new participant phone number: ");
        String phoneNumber = scanner.nextLine();

        Participant participant = new Participant(participantId, name, email, phoneNumber);
        participantDAO.updateParticipant(participant);
        System.out.println("Participant updated successfully.");
    }

    private static void deleteParticipant() throws SQLException {
    	System.out.println("===============================");
        System.out.print("Enter participant ID to delete: ");
        int participantId = scanner.nextInt();
        scanner.nextLine();

        participantDAO.deleteParticipant(participantId);
        System.out.println("Participant deleted successfully.");
    }

    private static void registerParticipantForEvent() throws SQLException {
    	System.out.println("===============================");
        System.out.print("Enter event ID: ");
        int eventId = scanner.nextInt();
        System.out.print("Enter participant ID: ");
        int participantId = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter registration date (YYYY-MM-DD): ");
        String registrationDate = scanner.nextLine();
        System.out.print("Enter registration status: ");
        String status = scanner.nextLine();

       
        int capacity = registrationDAO.getEventCapacity(eventId);
        if (capacity <= 0) {
            System.out.println("Registration failed: Event is at full capacity.");
            return;
        }

        Registration registration = new Registration(0, eventId, participantId, registrationDate, status);
        registrationDAO.registerParticipant(registration);
        System.out.println("Participant registered for event successfully.");
    }

    private static void viewAllRegistrationDetails() throws SQLException {
        List<Registration> registrations = registrationDAO.getAllRegistrations();
        if (registrations.isEmpty()) {
            System.out.println("No registrations found.");
        } else {
            for (Registration registration : registrations) {
            	System.out.println("===============================");
                System.out.println("Registration ID: " + registration.getRegistrationId());
                System.out.println("Event ID: " + registration.getEventId());
                System.out.println("Participant ID: " + registration.getParticipantId());
                System.out.println("Registration Date: " + registration.getRegistrationDate());
                System.out.println("Status: " + registration.getStatus());
                System.out.println();
            }
        }
    }

    private static void updateRegistration() throws SQLException {
    	System.out.println("===============================");
        System.out.print("Enter registration ID to update: ");
        int registrationId = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Enter new event ID: ");
        int eventId = scanner.nextInt();
        System.out.print("Enter new participant ID: ");
        int participantId = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter new registration date (YYYY-MM-DD): ");
        String registrationDate = scanner.nextLine();
        System.out.print("Enter new registration status: ");
        String status = scanner.nextLine();

        Registration registration = new Registration(registrationId, eventId, participantId, registrationDate, status);
        registrationDAO.updateRegistration(registration);
        System.out.println("Registration updated successfully.");
    }

    private static void cancelRegistration() throws SQLException {
    	System.out.println("===============================");
        System.out.print("Enter registration ID to cancel: ");
        int registrationId = scanner.nextInt();
        scanner.nextLine();

        registrationDAO.cancelRegistration(registrationId);
        System.out.println("Registration cancelled successfully.");
    }
}
