/**
 * 
 */
/**
 * 
 */
module Case_study {
	requires java.sql;
}