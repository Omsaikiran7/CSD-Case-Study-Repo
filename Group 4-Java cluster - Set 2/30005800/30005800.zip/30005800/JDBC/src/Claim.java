import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class Claim extends Member{
    public void InsertData() {
        Scanner sc=new Scanner(System.in);
        // variable declaration
        int ClaimID;
        int PolicyID;
        int MemberID;
        String ClaimDate;
        String Status;

        System.out.println("enter ClaimID");
        ClaimID=sc.nextInt();
        System.out.println("enter PolicyID");
        PolicyID = sc.nextInt();
        System.out.println("enter MemberID");
        MemberID=sc.nextInt();
        System.out.println("enter ClaimDate");
        ClaimDate=sc.next();
        System.out.println("enter Status");
        Status=sc.next();



        try {
            //connection building
            Connection obj = DriverManager.getConnection("jdbc:mysql://localhost:3306/healthinsurancepollicy", "root", "Santoshi3018");
            System.out.println(obj);
            System.out.println("Successful Connection");

            //1 adding data
            //query to insert data
            PreparedStatement ps = obj.prepareStatement("insert into Claim values(?,?,?,?,?)");


            //setting values
            ps.setInt(1,ClaimID);
            ps.setInt(2,PolicyID);
            ps.setInt(3,MemberID);
            ps.setString(4,ClaimDate);
            ps.setString(5,Status);

            int i = ps.executeUpdate();
            if (i > 0) {
                System.out.println("Success");
            } else {
                System.out.println("Fail");
            }

        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public void UpdateData() {
        Scanner sc=new Scanner(System.in);
        // variable declaration
        int ClaimID;
        int PolicyID;
        int MemberID;
        String ClaimDate;
        String Status;

        System.out.println("enter ClaimID");
        ClaimID=sc.nextInt();
        System.out.println("enter PolicyID");
        PolicyID = sc.nextInt();
        System.out.println("enter MemberID");
        MemberID=sc.nextInt();
        System.out.println("enter ClaimDate");
        ClaimDate=sc.next();
        System.out.println("enter Status");
        Status=sc.next();

        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/healthinsurancepollicy", "root", "Santoshi3018");
            PreparedStatement ps = con.prepareStatement("update Claim set PolicyID=?,MemberID=?,ClaimDate=?,Status=? where ClaimID=?");

            ps.setInt(1,PolicyID);
            ps.setInt(2,MemberID);
            ps.setString(3,ClaimDate);
            ps.setString(4,Status);
            ps.setInt(5,ClaimID);



            int count = ps.executeUpdate();
            if (count > 0) {
                System.out.println("Update Successful");
            } else {
                System.out.println("Update cancel");
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    public void DeleteData() {
        Scanner sc = new Scanner(System.in);
        int ClaimId;


        System.out.println("enter MemberId");
        ClaimId = sc.nextInt();

        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/healthinsurancepollicy", "root", "Santoshi3018");
            PreparedStatement ps = con.prepareStatement("delete from Claim where ClaimId=?");

            ps.setInt(1, ClaimId);

            int count = ps.executeUpdate();
            if (count > 0) {
                System.out.println("deletion Successful");
            } else {
                System.out.println("deletion cancel");
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    public void FetchData() {
        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/healthinsurancepollicy", "root", "Santoshi3018");
            PreparedStatement ps = con.prepareStatement("select * from Claim");
            ResultSet rs = ps.executeQuery();
            System.out.println("ClaimID"+"\t\t"+"PolicyID"+"\t\t\t"+"MemberID"+"\t\t\t"+"ClaimDate"+"\t\t\t"+"Status");
            while (rs.next()) {


                int ClaimID = rs.getInt("ClaimID");
                String PolicyID = String.valueOf(rs.getInt("PolicyID"));
                String MemberID = String.valueOf(rs.getInt("MemberID"));
                String ClaimDate =rs.getString("ClaimDate");
                String Status =rs.getString("Status");

                System.out.println(ClaimID+"\t\t\t\t"+PolicyID+"\t\t\t\t"+MemberID+"\t\t\t\t"+ClaimDate+"\t\t\t\t"+Status);

            }
        }catch (Exception e){
            e.printStackTrace();
        }

    }
}


