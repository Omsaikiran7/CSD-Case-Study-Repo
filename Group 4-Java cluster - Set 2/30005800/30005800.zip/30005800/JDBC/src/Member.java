import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class Member extends Policy{
    @Override
    public void InsertData() {
        Scanner sc=new Scanner(System.in);
        // variable declaration
        int MemberId;
        String Name;
        String DOB;
        String Email;
        String PhoneNumber;
        System.out.println("enter MemberId");
        MemberId=sc.nextInt();
        System.out.println("enter Name");
        Name = sc.next();
        sc.nextLine();
        System.out.println("enter DOB");
        DOB=sc.next();
        System.out.println("enter Email");
        Email=sc.next();
        System.out.println("enter PhoneNumber");
        PhoneNumber=sc.next();



        try {
            //connection building
            Connection obj = DriverManager.getConnection("jdbc:mysql://localhost:3306/healthinsurancepollicy", "root", "Santoshi3018");
            System.out.println(obj);
            System.out.println("Successful Connection");

            //1 adding data
            //query to insert data
            PreparedStatement ps = obj.prepareStatement("insert into Member values(?,?,?,?,?)");


            //setting values
            ps.setInt(1,MemberId);
            ps.setString(2,Name);
            ps.setString(3,DOB);
            ps.setString(4,Email);
            ps.setString(5,PhoneNumber);

            int i = ps.executeUpdate();
            if (i > 0) {
                System.out.println("Success");
            } else {
                System.out.println("Fail");
            }

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void UpdateData() {
        Scanner sc = new Scanner(System.in);
        int MemberId;
        String Name;
        String DateOfBirth;
        String Email;
        String PhoneNumber;
        System.out.println("enter MemberId");
        MemberId=sc.nextInt();
        System.out.println("set Name");
        Name = sc.next();
        sc.nextLine();
        System.out.println("set DateOfBirth");
        DateOfBirth=sc.next();
        System.out.println("set Email");
        Email=sc.next();
        System.out.println("set PhoneNumber");
        PhoneNumber=sc.next();

        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/healthinsurancepollicy", "root", "Santoshi3018");
            PreparedStatement ps = con.prepareStatement("update Member set Name=?,DateOfBirth=?,Email=?,PhoneNumber=? where MemberId=?");

            ps.setString(1,Name);
            ps.setString(2,DateOfBirth);
            ps.setString(3,Email);
            ps.setString(4,PhoneNumber);
            ps.setInt(5,MemberId);



            int count = ps.executeUpdate();
            if (count > 0) {
                System.out.println("Update Successful");
            } else {
                System.out.println("Update cancel");
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void DeleteData() {
        Scanner sc = new Scanner(System.in);
        int MemberId;


        System.out.println("enter MemberId");
        MemberId = sc.nextInt();

        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/healthinsurancepollicy", "root", "Santoshi3018");
            PreparedStatement ps = con.prepareStatement("delete from Member where MemberId=?");

            ps.setInt(1, MemberId);

            int count = ps.executeUpdate();
            if (count > 0) {
                System.out.println("deletion Successful");
            } else {
                System.out.println("deletion cancel");
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void FetchData() {
        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/healthinsurancepollicy", "root", "Santoshi3018");
            PreparedStatement ps = con.prepareStatement("select * from Member");
            ResultSet rs = ps.executeQuery();
            System.out.println("MemberId"+"\t\t"+"Name"+"\t\t\t\t\t"+"DateOfBirth"+"\t\t\t\t\t"+"Email"+"\t\t\t\t\t"+"PhoneNumber");
            while (rs.next()) {


                int MemberId = rs.getInt("MemberId");
                String Name = rs.getString("Name");
                String DateOfBirth =rs.getString("DateOfBirth");
                String Email =rs.getString("Email");
                String PhoneNumber =rs.getString("PhoneNumber");

                System.out.println(MemberId+"\t\t\t\t"+Name+"\t\t\t\t"+DateOfBirth+"\t\t\t\t"+Email+"\t\t\t\t"+PhoneNumber);

            }
        }catch (Exception e){
            e.printStackTrace();
        }

    }
    }

