
create database HealthInsurancePollicy;
USE HealthInsurancePollicy;
CREATE TABLE Policy (
    PolicyID INT PRIMARY KEY,
    PolicyNumber VARCHAR(20),
    Type VARCHAR(20),
    CoverageAmount DECIMAL(10, 2),
    PremiumAmount DECIMAL(10, 2)
    
);
INSERT INTO Policy (PolicyID, PolicyNumber, Type, CoverageAmount, PremiumAmount) VALUES
(1, 'POL123456', 'Health', 100000.00, 500.00),
(2, 'POL654321', 'Dental', 20000.00, 150.00),
(3, 'POL789012', 'Vision', 10000.00, 100.00);

CREATE TABLE Member (
    MemberID INT PRIMARY KEY,
    Name VARCHAR(100),
    DateOfBirth DATE,
    Email VARCHAR(100),
    PhoneNumber VARCHAR(15)
);
INSERT INTO Member (MemberID, Name, DateOfBirth, Email, PhoneNumber) VALUES
(1, 'John Doe', '1985-03-25', 'john.doe@example.com', '123-456-7890'),
(2, 'Jane Smith', '1990-07-14', 'jane.smith@example.com', '987-654-3210'),
(3, 'Emily Brown', '1978-11-09', 'emily.brown@example.com', '555-123-4567');
CREATE TABLE Claim (
    ClaimID INT PRIMARY KEY,
    PolicyID INT,
    MemberID INT,
    ClaimDate DATE,
    Status VARCHAR(20),
    FOREIGN KEY (PolicyID) REFERENCES Policy(PolicyID),
    FOREIGN KEY (MemberID) REFERENCES Member(MemberID)
);
INSERT INTO Claim (ClaimID, PolicyID, MemberID, ClaimDate, Status) VALUES
(101, 1, 1, '2024-06-10', 'Submitted'),
(102, 2, 2, '2024-06-15', 'Processed'),
(103, 3, 1, '2024-06-20', 'Submitted'),
(104, 1, 3, '2024-07-01', 'Processed');

SELECT * FROM Policy;
SELECT * FROM Member;
SELECT * FROM Claim;