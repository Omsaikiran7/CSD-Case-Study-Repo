REM   Script: Hospital Management
REM   Hospital Management

BEGIN 
    EXECUTE IMMEDIATE 'DROP TABLE Appointments'; 
    EXECUTE IMMEDIATE 'DROP TABLE Doctors'; 
    EXECUTE IMMEDIATE 'DROP TABLE Patients'; 
EXCEPTION 
    WHEN OTHERS THEN 
        NULL; 
END; 
/

BEGIN 
    EXECUTE IMMEDIATE 'DROP SEQUENCE Appointments_seq'; 
EXCEPTION 
    WHEN OTHERS THEN 
        NULL; 
END; 
/

CREATE TABLE Patients ( 
    PATIENT_ID NUMBER PRIMARY KEY, 
    FIRST_NAME VARCHAR2(50), 
    LAST_NAME VARCHAR2(50), 
    DATE_OF_BIRTH DATE, 
    GENDER VARCHAR2(10), 
    CONTACT_NUMBER VARCHAR2(15), 
    ADDRESS VARCHAR2(200) 
);

CREATE TABLE Doctors ( 
    DOCTOR_ID NUMBER PRIMARY KEY, 
    FIRST_NAME VARCHAR2(50), 
    LAST_NAME VARCHAR2(50), 
    SPECIALIZATION VARCHAR2(50), 
    CONTACT_NUMBER VARCHAR2(15), 
    EMAIL VARCHAR2(100) 
);

CREATE TABLE Appointments ( 
    APPOINTMENT_ID NUMBER PRIMARY KEY, 
    PATIENT_ID NUMBER, 
    DOCTOR_ID NUMBER, 
    APPOINTMENT_DATE DATE, 
    APPOINTMENT_TIME VARCHAR2(10), 
    STATUS VARCHAR2(20), 
    FOREIGN KEY (PATIENT_ID) REFERENCES Patients(PATIENT_ID), 
    FOREIGN KEY (DOCTOR_ID) REFERENCES Doctors(DOCTOR_ID) 
);

CREATE SEQUENCE Appointments_seq 
START WITH 1 
INCREMENT BY 1;

INSERT INTO Patients (PATIENT_ID, FIRST_NAME, LAST_NAME, DATE_OF_BIRTH, GENDER, CONTACT_NUMBER, ADDRESS) VALUES 
(1, 'Megha', 'Shree', TO_DATE('2002-08-05', 'YYYY-MM-DD'), 'Female', '1234567890', '123 cross cut');

INSERT INTO Patients (PATIENT_ID, FIRST_NAME, LAST_NAME, DATE_OF_BIRTH, GENDER, CONTACT_NUMBER, ADDRESS) VALUES 
(2, 'Aishu', '', TO_DATE('2002-09-05', 'YYYY-MM-DD'), 'Female', '9123456780', '456 abc road');

INSERT INTO Doctors (DOCTOR_ID, FIRST_NAME, LAST_NAME, SPECIALIZATION, CONTACT_NUMBER, EMAIL) VALUES 
(1, 'Ajay', 'Kumar', 'Cardiology', '9595959595', 'ajay.kumar@hosp.com');

INSERT INTO Doctors (DOCTOR_ID, FIRST_NAME, LAST_NAME, SPECIALIZATION, CONTACT_NUMBER, EMAIL) VALUES 
(2, 'Sanjay', 'Vignesh', 'Neurology', '9898989898', 'sanjay.vignesh@hosp.com');

INSERT INTO Appointments (APPOINTMENT_ID, PATIENT_ID, DOCTOR_ID, APPOINTMENT_DATE, APPOINTMENT_TIME, STATUS) VALUES 
(1, 1, 1, TO_DATE('2024-08-20', 'YYYY-MM-DD'), '9:00 AM', 'Scheduled');

INSERT INTO Appointments (APPOINTMENT_ID, PATIENT_ID, DOCTOR_ID, APPOINTMENT_DATE, APPOINTMENT_TIME, STATUS) VALUES 
(2, 2, 2, TO_DATE('2024-08-21', 'YYYY-MM-DD'), '11:00 AM', 'Scheduled');

CREATE OR REPLACE PROCEDURE ScheduleAppointment ( 
    p_patient_id IN NUMBER, 
    p_doctor_id IN NUMBER, 
    p_appointment_date IN DATE, 
    p_appointment_time IN VARCHAR2, 
    p_status IN VARCHAR2 
) AS 
    v_doctor_availability NUMBER; 
BEGIN 
    SELECT COUNT(*) INTO v_doctor_availability 
    FROM Appointments 
    WHERE DOCTOR_ID = p_doctor_id 
    AND APPOINTMENT_DATE = p_appointment_date 
    AND APPOINTMENT_TIME = p_appointment_time; 
     
    IF v_doctor_availability = 0 THEN 
        INSERT INTO Appointments (APPOINTMENT_ID, PATIENT_ID, DOCTOR_ID, APPOINTMENT_DATE, APPOINTMENT_TIME, STATUS) 
        VALUES (Appointments_seq.NEXTVAL, p_patient_id, p_doctor_id, p_appointment_date, p_appointment_time, p_status); 
    ELSE 
        DBMS_OUTPUT.PUT_LINE('Doctor is not available.'); 
    END IF; 
END; 
/

CREATE OR REPLACE PROCEDURE DischargePatient ( 
    p_patient_id IN NUMBER 
) AS 
BEGIN 
    UPDATE Appointments 
    SET STATUS = 'Cancelled' 
    WHERE PATIENT_ID = p_patient_id 
    AND STATUS = 'Scheduled'; 
     
    DBMS_OUTPUT.PUT_LINE('Patient is discharged and all pending appointments cancelled.'); 
END; 
/

